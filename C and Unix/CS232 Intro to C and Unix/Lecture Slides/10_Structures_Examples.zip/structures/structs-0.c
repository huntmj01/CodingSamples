/**
 * structs-0.c
 * 
 * This example is modifed from an example in CS50 by David J. Malan
 *
 * Demonstrates use of structs.
 */
       
#include <cs50.h>
#include <stdio.h>
#include <string.h>

// structure representing a student
struct student
{
    int id;
    int score;
};

// number of students
#define STUDENTS 3

int main(void)
{
    int i;
    
    // declare students
    struct student students[STUDENTS];

    // populate students with user's input
    for (i = 0; i < STUDENTS; i++)
    {
        printf("Student's id: ");
        students[i].id = GetInt();
        
        printf("Student's score: ");
        students[i].score = GetInt();
    }

    // now print students' info
    for (i = 0; i < STUDENTS; i++)
    {
        printf("Student %d got %d.\n", students[i].id, students[i].score);
    }
    
    // calculate the average of the score
    {
        int sum = 0;
        for (i = 0; i < STUDENTS; i++)
            sum += students[i].score;
            
        printf("Students' average is %f.\n", sum * 1.0 / STUDENTS);
    }
}