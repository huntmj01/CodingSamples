#include <stdio.h>
#include <string.h>

struct room {
    char building[5];
    int number;
    int capacity;
};
    
struct course {
    char dept[5];
    int number;
    char *name;
    struct room *pRoom;
    int enrollment;
};

void print_course_info(struct course *pCourse);

main() {
    struct room kt250;
    struct course cs232;
    struct course cs260;
    
    char cs232_course_name[] = "Introduction to Unix and C";
    char cs260_course_name[] = "Data Structure";
    
    strncpy(kt250.building, "KT", sizeof(kt250.building));
    kt250.number = 250;
    kt250.capacity = 30;
    
    strncpy(cs232.dept, "CS", sizeof(cs232.dept));
    cs232.number =  232;
    cs232.name = cs232_course_name;
    cs232.pRoom = &kt250;
    cs232.enrollment = 19;
    
    strncpy(cs260.dept, "CS", sizeof(cs260.dept));
    cs260.number = 260;
    cs260.name = cs260_course_name;
    cs260.pRoom = &kt250;
    cs260.enrollment = 28;
    
    print_course_info(&cs232);
    print_course_info(&cs260);
}

void print_course_info(struct course *pCourse) {
    if (pCourse == NULL) {
        printf("pCourse is NULL!\n");
        return;
    }
    
    printf("%s%d %s is using room %s%d (campcity: %d) and with %d students. \n", pCourse->dept, pCourse->number, pCourse->name, 
        pCourse->pRoom->building, pCourse->pRoom->number, pCourse->pRoom->capacity, pCourse->enrollment);
}