#include <stdio.h>

void do_something(short argu);

main()
{
    int db_table_key = 32767;
    
    printf ("db_table_key = %d\t", db_table_key);
    do_something(db_table_key);
    
    db_table_key ++;
    printf ("db_table_key = %d\t", db_table_key);
    do_something(db_table_key);
}

void do_something(short argu)
{
    printf("argu = %d\n", argu);
}
