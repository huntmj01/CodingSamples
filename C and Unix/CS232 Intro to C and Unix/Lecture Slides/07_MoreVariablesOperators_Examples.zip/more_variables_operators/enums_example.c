#include <stdio.h>

main()
{
    enum classIDs {ID232=2, ID271, ID161=1, ID160};
    
    printf("ID271 has value %d\n", ID271);
    printf("ID160 has value %d\n", ID160);
}
