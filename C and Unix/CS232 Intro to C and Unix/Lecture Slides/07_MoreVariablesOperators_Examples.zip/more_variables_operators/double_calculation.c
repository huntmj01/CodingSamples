#include <stdio.h>

int main()
{
    double a = 1.03;
    double b = 0.42;
    double c;
    
    c = a - b;
    
    printf ("The result is %.20f\n", c);
    
    printf ("Calculate 1.00 - 9 * 0.1 = %.20f\n", 1.00 - 9 * 0.1);
}