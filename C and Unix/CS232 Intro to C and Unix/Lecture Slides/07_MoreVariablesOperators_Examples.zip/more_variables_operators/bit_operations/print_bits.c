#include <stdio.h>

void printBits(const int x){
	const int numBits = sizeof(x) * 8;
	int i;

	printf("The bit representation of the int %d is:", x);
	for(i=numBits-1; i >= 0; i--) {
		const int mask = (1 << i);
		int bit = 1;
		if((mask & x) == 0) {
			bit = 0;
		}
		printf("%d", bit);
   }
	printf("\n");
}

main()
{
    int x = 13;
    printBits(x);
    
    x = 123;
    printBits(x);
}