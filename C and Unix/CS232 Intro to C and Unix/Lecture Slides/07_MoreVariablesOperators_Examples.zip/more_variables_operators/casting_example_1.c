#include <stdio.h>

int main()
{
    int a = 32767;
    short b;
    
    printf ("size of int = %ld, size of short = %ld\n", sizeof(int), sizeof(short));   
    
    b = (short)a;    
    printf ("a = %d, b = %d\n", a, b);
    
    a ++;
    b = (short)a;    
    printf ("a = %d, b = %d\n", a, b);
    
    return 0;
}
