#include <stdlib.h>

int main() {
    system("ls -altr | grep -F .c");
    
    return 0;
}