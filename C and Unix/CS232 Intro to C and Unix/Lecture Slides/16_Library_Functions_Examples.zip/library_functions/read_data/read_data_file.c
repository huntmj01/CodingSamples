#include "read_data_file.h"

struct arrayOfVectors* readData(const char* filename){
  struct arrayOfVectors* pResult = NULL;
  int lineIndex, res;
  const int bufSize = 10000;
  char line[bufSize];
  FILE *fp = NULL;

  pResult = malloc(sizeof(struct arrayOfVectors));
  if(pResult == NULL){
    fprintf(stderr, "Could not allocate memory.\n");
    return NULL;
  }

  fp = fopen(filename, "r");
  if(fp == NULL){
    fprintf(stderr, "Could not open the file (%s).\n",
	    filename);
    free(pResult);
    return NULL;
  }

  res = fscanf(fp, "%d\n", &pResult->numRows);
  if(res != 1 || pResult->numRows > 1000000 ||
			 pResult->numRows <= 0){
    fprintf(stderr, "Invalid number of lines.\n");
    fclose(fp);
    free(pResult);
    return NULL;
  }
  
  pResult->theData = malloc(sizeof(int*) * pResult->numRows);
  if(pResult->theData == NULL){
    fprintf(stderr, "Could not allocate memory.\n");
    fclose(fp);
    free(pResult);
    return NULL;
  }
  
  pResult->rowSizes = malloc(sizeof(int) * pResult->numRows);
  if(pResult->rowSizes == NULL) {
    fprintf(stderr, "Could not allocate memory.\n");
    free(pResult->theData);
    fclose(fp);
    free(pResult);
    return NULL;
  }

  for(lineIndex=0; lineIndex<pResult->numRows; lineIndex++){
    fgets(line, bufSize, fp);
    
    /* by using fgets, we have a string to pass
       to createIntArray, which can manipulate it
       as necessary (in contrast to using fscanf) */
    pResult->theData[lineIndex] = createIntArray(line, pResult->rowSizes + lineIndex);
  }

  fclose(fp);
  return pResult;
}

int* createIntArray(const char* line, int* pNumInts){
  const char *pChar;
  int res, val, charsRead;
  /** count the ints **/
  *pNumInts = 0;
  pChar = line;
  /* While there is more string to process */
  while(1){
	 /* Check for an int */
    res = sscanf(pChar, "%d%n", &val, &charsRead);
    if(res == 1){
      (*pNumInts)++;
	   /* Move the pointer past the int */
      pChar = pChar + charsRead;
    }
    else{
      break;
    }
  } 
  
  int* arr = NULL;
	
   /** allocate the space **/
   arr = malloc(sizeof(int) * (*pNumInts));
   if(arr == NULL)
      return NULL;

  /** convert the tokens to ints, filling arr **/
  int i;
  pChar = line;
  /* for each integer */
  for(i=0; i<*pNumInts; i++){
	 /* read the int */
    sscanf(pChar, "%d%n", &(arr[i]), &charsRead);
    /* move the pointer past the int */
    pChar = pChar + charsRead;
  } 
  return arr;
}

void printData(struct arrayOfVectors* pStruct) {
  int lineIndex, intIndex;
  
  for (lineIndex = 0; lineIndex < pStruct->numRows; lineIndex++) {
    printf("Line %d: ", lineIndex);
    
    for (intIndex = 0; intIndex < pStruct->rowSizes[lineIndex]; intIndex++) {
      printf("%d, ", pStruct->theData[lineIndex][intIndex]);
    }
    printf("\n");
  }
}

void freeArrayOfVectors(struct arrayOfVectors* pStruct) {
    int lineIndex;
    
    for(lineIndex = 0; lineIndex < pStruct->numRows; lineIndex++){
        free(pStruct->theData[lineIndex]);
    }
    
    free(pStruct->theData);
    free(pStruct->rowSizes);
    free(pStruct);
}
