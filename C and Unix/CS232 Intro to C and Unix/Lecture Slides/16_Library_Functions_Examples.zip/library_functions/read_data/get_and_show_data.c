#include "read_data_file.h"

int main() {
    char filename[] = "data.txt";
    struct arrayOfVectors* pStruct;
    
    pStruct = readData(filename);
    if (pStruct == NULL) {
        printf("ERROR: Fetch data from %s\n", filename);
        return -1;
    }
    
    printData(pStruct);
    
    freeArrayOfVectors(pStruct);
    
    return 0;
}
