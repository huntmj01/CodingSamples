#ifndef READ_DATA_FILE_H_
#define READ_DATA_FILE_H_

#include <stdio.h>
#include <stdlib.h>

struct arrayOfVectors {
  int numRows;

  /* an array of size numRows */
  int *rowSizes;

  /* an array of size numRows;
     theData[i] points to an array
	  of int's of size rowSizes[i] */
  int **theData;
};

struct arrayOfVectors* readData(const char* filename);
int* createIntArray(const char* line, int* pNumInts);
void printData(struct arrayOfVectors* pStruct);
void freeArrayOfVectors(struct arrayOfVectors* pStruct);

#endif
