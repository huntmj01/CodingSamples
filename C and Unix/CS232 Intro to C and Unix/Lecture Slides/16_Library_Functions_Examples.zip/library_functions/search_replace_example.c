#include <stdio.h>
#include <stdlib.h>
#include <string.h>

enum errorCodes {ERR_INVALID_ARGS = 1, ERR_FILE_OPEN, ERR_MALLOC};
int main(int argc, char* argv[]){
	/* provide names for readability */
	const char *sourceFile, *destFile, *searchStr, *replStr;

    /* verity the arguments */
	if(argc != 5){
		fprintf(stderr, "USAGE: sourceFile destFile searchStr replacementStr\n");
		return ERR_INVALID_ARGS;
	}

	sourceFile = argv[1];
	destFile = argv[2];
	searchStr = argv[3];
	replStr = argv[4];

    /* open the files */
    FILE *fpIn, *fpOut;
    fpIn = fopen(sourceFile, "r");
    if(fpIn == NULL){
     	fprintf(stderr, "Could not open source file (%s).\n", sourceFile);
       	return ERR_FILE_OPEN;
    }
    fpOut = fopen(destFile, "w");
    if(fpOut == NULL){
      	fprintf(stderr, "Could not open destination (%s).\n", destFile);
       	return ERR_FILE_OPEN;
    }
    
    /* read a line */
    const int maxLength = 10000;
    char *line = malloc(sizeof(char) * maxLength);
    if(line == NULL){
    	fprintf(stderr, "Could not allocate memory.\n");
    	return ERR_MALLOC;
    }
    
    while(fgets(line, maxLength, fpIn) != NULL) {
    	int lineLen;
    	lineLen = strlen(line);
    	if(lineLen > 0){
    		if(line[lineLen-1] != '\n'){
    			fprintf(stderr, "WARNING: line is too long or the"
    					" file does not end with a blank line.\n");
    			line[lineLen-1] = '\n';
    		}
    		
            char *pNextSpot, *pNextSearchStr;
            pNextSpot = line;
            do{
            	pNextSearchStr = strstr(pNextSpot, searchStr);
            	if(pNextSearchStr == NULL)
            		fputs(pNextSpot, fpOut);
            	else{
            		/* we can overwrite the first character of
            			pNextSearchStr because we don't need it */
            		*pNextSearchStr = '\0';
            		fputs(pNextSpot, fpOut);
            		fputs(replStr, fpOut);
            
            		pNextSpot = pNextSearchStr + strlen(searchStr);
            	}
            } while(pNextSearchStr != NULL);
        }
    }    

    free(line);
    fclose(fpOut);
    fclose(fpIn);
    
    return 0;
}