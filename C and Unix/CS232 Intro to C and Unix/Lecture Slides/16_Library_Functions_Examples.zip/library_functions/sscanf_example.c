#include <stdio.h>
#include <stdlib.h>

#define NUMCOLS 3

int main() {
    const char* filename = "num.txt";
    FILE * fp;
    int sums[NUMCOLS] = {0, 0, 0};
    const int bufSize = 200;
    char line[bufSize];
    int i, j, res, n;
    
    fp = fopen(filename, "r");
    if(fp == NULL){
		fprintf(stderr, "Could not open file (%s).\n", filename);
		return -1;
	}
	
    res = fscanf(fp, "%d\n", &n);
    if(res != 1) {
        fprintf(stderr, "File format error.\n");
        return -1;
    }
    
    for(i=0; i<n; i++){
    	int vals[NUMCOLS];
    	
    	fgets(line, bufSize, fp);
    	
    	res = sscanf(line, "%d %d %d\n", vals, vals+1, vals+2);
    	if(res != 3)
    		fprintf(stderr, "Line %d was too short.\n", i+1);
    	else{
    		for(j=0; j<NUMCOLS; j++)
    			sums[j] += vals[j];
    	}
    }
    
    printf("%d %d %d\n", sums[0], sums[1], sums[2]);
    
    return 0;
}