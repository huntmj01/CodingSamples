#include <stdio.h>
#include <string.h>

int main(int argc, char* argv[]) {
    const int MAX_LENGTH = 500;
    char joinedStr[MAX_LENGTH + 1];

    /* fill in here */
    
    


    
    printf("The concatenated string is %s\n.", joinedStr);
    return 0;
}
