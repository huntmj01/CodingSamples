#ifndef MUL_DIV_H_
#define MUL_DIV_H_

int mul(int a, int b);
double div(int a, int b);

#endif
